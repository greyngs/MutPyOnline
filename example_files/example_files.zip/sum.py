def suma(a,b):
    c = a+b
    if a == b:
        return 100
    return c